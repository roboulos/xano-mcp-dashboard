import GeneralError from "@/components/errors/general-error"

export default function GeneralErrorPage() {
  return <GeneralError />
}
