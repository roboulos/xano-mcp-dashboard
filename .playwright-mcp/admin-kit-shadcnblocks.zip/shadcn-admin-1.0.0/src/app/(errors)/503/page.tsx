import MaintenanceError from "@/components/errors/maintenance-error"

export default function MaintenanceErrorPage() {
  return <MaintenanceError />
}
