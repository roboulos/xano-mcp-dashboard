import NotFoundError from "@/components/errors/not-found-error"

export default function NotFoundErrorPage() {
  return <NotFoundError />
}
