import UnauthorizedError from "@/components/errors/unauthorized-error"

export default function UnauthorizedErrorPage() {
  return <UnauthorizedError />
}
