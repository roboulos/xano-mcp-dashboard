import ForbiddenError from "@/components/errors/forbidden"

export default function ForbiddenErrorPage() {
  return <ForbiddenError />
}
